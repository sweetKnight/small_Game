//
//  ViewController.m
//  ClearMinesTest
//
//  Created by 冯剑锋 on 15/10/28.
//  Copyright © 2015年 冯剑锋. All rights reserved.
//

#import "ViewController.h"
#import "MineCollectionViewCell.h"

static NSString * const reuseIdentifier = @"Cell";
@interface ViewController ()<UICollectionViewDataSource, UICollectionViewDelegate>
{
    int _roundNumber;
    NSString * _mouseFlag;
    int _mineNumber;
    int _OKNumber;
}

@property (nonatomic,strong) NSMutableArray * minesArray;

@property (weak, nonatomic) IBOutlet UICollectionView *minesColloctionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *flagButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *OKNumberButton;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *mineNumberButton;

@end

@implementation ViewController


#pragma mark - init

-(void)setOKNumberButton:(UIBarButtonItem *)OKNumberButton{
    _OKNumberButton = OKNumberButton;
    _OKNumberButton.enabled = NO;
}

-(void)setMineNumberButton:(UIBarButtonItem *)mineNumberButton{
    _mineNumberButton = mineNumberButton;
    _mineNumberButton.enabled = NO;
}

-(void)setMinesColloctionView:(UICollectionView *)minesColloctionView{
    _minesColloctionView = minesColloctionView;
    
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    CGFloat cellWidth = [UIScreen mainScreen].bounds.size.width/14;
    CGFloat cellHeight = [UIScreen mainScreen].bounds.size.height/18;
    layout.itemSize = CGSizeMake(cellWidth, cellHeight);
    layout.minimumLineSpacing = 2;
    layout.minimumInteritemSpacing = 2;
    
    _minesColloctionView.collectionViewLayout = layout;
    _minesColloctionView.dataSource =self;
    _minesColloctionView.delegate = self;
    
//    [_minesColloctionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    [_minesColloctionView registerClass:[MineCollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
}

-(NSMutableArray *)minesArray{
    if (nil == _minesArray) {
        _minesArray = [[NSMutableArray alloc]init];
    }
    return _minesArray;
}

#pragma mark - lifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _mouseFlag = @"Normal";
    _OKNumber = 175;
    _mineNumber = 20;
    [self changeNumberOfminesAndOK];
    
//    [self showMessage:@"woqu"];
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 195;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MineCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.backgroundColor = [UIColor greenColor];
//    cell.numberLabel.text = [NSString stringWithFormat:@"%i", indexPath.row];
    cell.numberLabel.text = @"";
    cell.pos = NO;
    [self giveMinesArrayValue];
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    MineCollectionViewCell * cell = (MineCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    if ([_mouseFlag isEqualToString:@"Normal"]) {
        for (int i = 0; i < self.minesArray.count; i++) {
            if (indexPath.row == [self.minesArray[i] intValue]) {
                cell.backgroundColor = [UIColor redColor];
                [self showMessage:@"bangbangbang~"];
                
                for (UIView * view in _minesColloctionView.subviews) {
                    if ([view isKindOfClass:[MineCollectionViewCell class]]) {
                        MineCollectionViewCell * cell = (MineCollectionViewCell *)view;
                        if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i",(int)[_minesColloctionView indexPathForCell:cell].row]]) {
                            cell.backgroundColor = [UIColor redColor];
                        }
                    }
                    
                }
                return;
            }
        }
        cell.backgroundColor = [UIColor yellowColor];
        
        [self numberAddForCell:indexPath AndCell:cell];
        
        if (cell.pos == NO) {
            _OKNumber--;
            [self changeNumberOfminesAndOK];
        }
        cell.pos = YES;
        
        
    }else if([_mouseFlag isEqualToString:@"Flag"]){
        cell.backgroundColor = [UIColor blackColor];
        _mouseFlag = @"Normal";
        
        
        if (cell.pos == NO) {
            _mineNumber--;
            [self changeNumberOfminesAndOK];
        }
        cell.pos = YES;
    }
    
//    if ([_mouseFlag isEqualToString:@"Flag"]) {
//        _mouseFlag = @"Normal";
//        return;
//    }
    if (_OKNumber == 0) {
        [self showMessage:@"恭喜你胜利"];
    }
    
}

#pragma mark -buttonClick

- (IBAction)flagButtonClick:(id)sender {
    if ([_mouseFlag isEqualToString:@"Normal"]) {
        _mouseFlag = @"Flag";
        return;
    }
    if ([_mouseFlag isEqualToString:@"Flag"]) {
        _mouseFlag = @"Normal";
        return;
    }
    
}

#pragma main - customMethods

-(void)giveMinesArrayValue{
    [self.minesArray removeAllObjects];
    
    while (1) {
        int number = arc4random()%194;
        NSString * minesNumber = [NSString stringWithFormat:@"%i",number];
        if (![self.minesArray containsObject:minesNumber]) {
            [self.minesArray addObject:minesNumber];
        }
        if (self.minesArray.count == 20) {
            return;
        }
    }
}

-(void) showMessage:(NSString *)message{
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * canceButoon = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [_minesColloctionView reloadData];
    }];
    [alertController addAction:canceButoon];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

-(void)numberAddForCell:(NSIndexPath *)indexPath AndCell:(MineCollectionViewCell *)cell{
    _roundNumber = 0;
    
    NSArray * topNumberArray    = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"];
    NSArray * leftNumberArray   = @[@"0",@"13",@"26",@"39",@"52",@"65",@"78",@"91",@"104",@"117",@"130",@"143",@"156",@"169",@"182"];
    NSArray * rightNumberArray  = @[@"12",@"25",@"38",@"51",@"64",@"77",@"90",@"103",@"116",@"129",@"142",@"155",@"168",@"181",@"194"];;
    NSArray * bottomNumberArray = @[@"182",@"183",@"184",@"185",@"186",@"187",@"188",@"189",@"190",@"191",@"192",@"193",@"194"];
    
//    NSString * leftTop     = @"0";
//    NSString * leftButtom  = @"182";
//    NSString * rightTop    = @"12";
//    NSString * rightButtom = @"194";
    
    //四个角时的判断
    int leftTop     = 0;
    int leftButtom  = 182;
    int rightTop    = 12;
    int rightButtom = 194;
    
    if (indexPath.row == leftTop) {
        NSArray * leftToproundArray = @[@"1",@"13",@"14"];
        [leftToproundArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString * numberString = obj;
            if ([self.minesArray containsObject:numberString]) {
                _roundNumber++;
            };
        }];
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    }
    if (indexPath.row == rightTop) {
        NSArray * rightToproundArray = @[@"11",@"24",@"25"];
        [rightToproundArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString * numberString = obj;
            if ([self.minesArray containsObject:numberString]) {
                _roundNumber++;
            };
        }];
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    }
    if (indexPath.row == leftButtom) {
        NSArray * leftButtomroundArray = @[@"169",@"170",@"183"];
        [leftButtomroundArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString * numberString = obj;
            if ([self.minesArray containsObject:numberString]) {
                _roundNumber++;
            };
        }];
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    }
    if (indexPath.row == rightButtom) {
        NSArray * rightButtomroundArray = @[@"180",@"181",@"193"];
        [rightButtomroundArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString * numberString = obj;
            if ([self.minesArray containsObject:numberString]) {
                _roundNumber++;
            };
        }];
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    }
    
    //四个边时的判断
    if ([topNumberArray containsObject:[NSString stringWithFormat:@"%i", (int)indexPath.row]]) {
        for (int i = 0; i < 9; i++) {
            int number = 500;
            if (i < 3) {
//                number = (int)(indexPath.row - 14 + i);
            }else if (i < 6){
                number = (int)(indexPath.row - 1 + (i - 3));
            }else{
                number = (int)(indexPath.row + 12 + (i - 6));
            }
            if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i", number]]) {
                _roundNumber++;
            };
        }
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    };
    
    if ([bottomNumberArray containsObject:[NSString stringWithFormat:@"%i", (int)indexPath.row]]) {
        for (int i = 0; i < 9; i++) {
            int number = 500;
            if (i < 3) {
                number = (int)(indexPath.row - 14 + i);
            }else if (i < 6){
                number = (int)(indexPath.row - 1 + (i - 3));
            }else{
//                number = (int)(indexPath.row + 12 + (i - 6));
            }
            if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i", number]]) {
                _roundNumber++;
            };
            
        }
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    };
    
    //左边
    if ([leftNumberArray containsObject:[NSString stringWithFormat:@"%i", (int)indexPath.row]]) {
        for (int i = 0; i < 5; i++) {
            int number = 500;
            if (i < 2) {
                number = (int)(indexPath.row - 13 + 26*i);
            }else{
                number = (int)(indexPath.row + 1) + 13* (i - 3);
            }
            if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i", number]]) {
                _roundNumber++;
            };
            
        }
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    };
    
    //右边
    if ([rightNumberArray containsObject:[NSString stringWithFormat:@"%i", (int)indexPath.row]]) {
        for (int i = 0; i < 5; i++) {
            int number = 500;
            if (i < 2) {
                number = (int)(indexPath.row - 13 + 26*i);
            }else{
                number = (int)(indexPath.row - 1) + 13* (i - 3);
            }
            if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i", number]]) {
                _roundNumber++;
            };
            
        }
        cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
        return;
    };
    
    
    //中间的判断
    for (int i = 0; i < 9; i++) {
        int number;
        if (i < 3) {
            number = (int)(indexPath.row - 14 + i);
        }else if (i < 6){
            number = (int)(indexPath.row - 1 + (i - 3));
        }else{
            number = (int)(indexPath.row + 12 + (i - 6));
        }
        if ([self.minesArray containsObject:[NSString stringWithFormat:@"%i", number]]) {
            _roundNumber++;
        };
        
        //        NSIndexPath * index = [NSIndexPath indexPathForRow:number inSection:0];
        //         MineCollectionViewCell * cell = (MineCollectionViewCell *)[collectionView cellForItemAtIndexPath:index];
        //        cell.backgroundColor = [UIColor redColor];
        
        //        for (int i = 0; i < self.minesArray.count; i++) {
        //            if (number == [self.minesArray[i] intValue]) {
        //                roundNumber++;
        //            }
        //        }
    }
    cell.numberLabel.text = [NSString stringWithFormat:@"%i", _roundNumber];
}

-(void)changeNumberOfminesAndOK{
    [_mineNumberButton setTitle:[NSString stringWithFormat:@"%i",_mineNumber]];
    [_OKNumberButton setTitle:[NSString stringWithFormat:@"%i",_OKNumber]];
}

@end
