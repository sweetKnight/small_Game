//
//  MineCollectionViewCell.m
//  ClearMinesTest
//
//  Created by 冯剑锋 on 15/10/28.
//  Copyright © 2015年 冯剑锋. All rights reserved.
//

#import "MineCollectionViewCell.h"

@interface MineCollectionViewCell ()

@end

@implementation MineCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _numberLabel = [[UILabel alloc]init];
        _numberLabel.font =[UIFont systemFontOfSize:13.0];
        _numberLabel.textAlignment = NSTextAlignmentCenter;
        _numberLabel.textColor = [UIColor redColor];
        [self.contentView addSubview:_numberLabel];
        
//        _mineImageView = [[UIImageView alloc]init];
//        _mineImageView.hidden = YES;
//        [self.contentView addSubview:_numberLabel];
    }
    return self;
}

-(void)layoutSubviews{
    _numberLabel.frame = self.contentView.frame;
//    _mineImageView.frame = self.contentView.frame;
}

@end
