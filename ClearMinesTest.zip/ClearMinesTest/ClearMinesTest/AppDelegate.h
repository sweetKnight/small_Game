//
//  AppDelegate.h
//  ClearMinesTest
//
//  Created by 冯剑锋 on 15/10/28.
//  Copyright © 2015年 冯剑锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

