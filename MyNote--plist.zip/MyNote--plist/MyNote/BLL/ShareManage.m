//
//  ShareManage.m
//  ZhongGuoCha
//
//  Created by 张长乐 on 15/5/20.
//  Copyright (c) 2015年 BMCL. All rights reserved.
//

#import "ShareManage.h"

@implementation ShareManage



/**
 *  分享
 *
 *  @param shareType 分享类型
 */
+ (void)shareHandlerByShareType:(ShareType)shareType prameDic:(NSDictionary*)dic backBlock:(void(^)(BOOL isSUC))backBlcok
{
    NSString*title=[dic objectForKey:@"title"];
    NSString *titleOther;
    if ([dic allValues].count==4) {
        titleOther=[dic objectForKey:@"otherTitle"];
    }else{
        titleOther=title;
    }
    if (shareType==ShareTypeSinaWeibo) {
        title=[[dic objectForKey:@"title"] stringByAppendingString:[dic objectForKey:@"url"]];
    }
    if (shareType==ShareTypeWeixiSession) {
        //微信好友
        if ([dic allValues].count==4) {
            title=[dic objectForKey:@"otherTitle"];
            titleOther=[dic objectForKey:@"title"];
        }else{
            titleOther=title;
        }
    }
    if (shareType==ShareTypeWeixiTimeline) {
        //朋友圈
        if ([dic allValues].count==4) {
            titleOther=[dic objectForKey:@"otherTitle"];
            title=[dic objectForKey:@"title"];
        }else{
            titleOther=title;
        }
    }
    NSData *data=[NSData dataWithContentsOfURL:[NSURL URLWithString:[dic objectForKey:@"imageURL"]]];
    
    //创建分享内容
    id<ISSContent> publishContent = [ShareSDK content:title
                                       defaultContent:title
                                                image:[ShareSDK imageWithData:data fileName:@"pict" mimeType:@"image/png"]
                                                title:titleOther
                                                  url:[dic objectForKey:@"url"]
                                          description:title
                                            mediaType:SSPublishContentMediaTypeNews];
    /*
    //显示分享菜单
    //客户端分享（仅支持新浪微博、微信、QQ、Pinterest、Google+）
    
    [ShareSDK clientShareContent:publishContent //内容对象
                            type:shareType //平台类型
                   statusBarTips:YES
                          result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {//返回事件
                              
                              if (state == SSPublishContentStateSuccess)
                              {
                                  NSLog(NSLocalizedString(@"TEXT_SHARE_SUC", @"分享成功!"));

                                  backBlcok(YES);
                              }
                              else if (state == SSPublishContentStateFail)
                              {
                                  NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"分享失败!"), [error errorCode], [error errorDescription]);
                                   backBlcok(NO);
                                  NSLog(@"%@--%ld",[error errorDescription],[error errorCode]);
                              }
                          }];
    
    */
    
    
    
    
    //显示编辑框
    [ShareSDK showShareViewWithType:shareType
                          container:nil
                            content:publishContent
                      statusBarTips:YES
                        authOptions:nil
                       shareOptions:nil
                             result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
                                 
                                 if (state == SSPublishContentStateSuccess)
                                 {
                                     NSLog(NSLocalizedString(@"TEXT_SHARE_SUC", @"发表成功"));
                                      backBlcok(YES);
                                 }
                                 else if (state == SSPublishContentStateFail)
                                 {
                                     NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"发布失败!error code == %d, error code == %@"), [error errorCode], [error errorDescription]);
                                      backBlcok(NO);
                                 }
                                 else if (state == SSPublishContentStateCancel)
                                 {
                                     NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"发布失败!error code == %d, error code == %@"), [error errorCode], [error errorDescription]);
                                     backBlcok(NO);
                                 }
                             }];
    
    
}

@end
