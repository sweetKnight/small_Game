//
//  NoteBl.h
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Note.h"

@interface NoteBl : NSObject
/*!
 *  创建一条新的备忘录
 */
+(NSMutableArray *)createNote:(Note *)model;
/*!
 *  删除一条备忘录
 */
+(NSMutableArray *)remove:(Note *)model;
/*!
 *  查询全部备忘录数据
 */
+(NSMutableArray *)findAll;
/*!
 *  修改一条信息
 */
+(NSMutableArray *)chageNote:(Note *)model;
@end
