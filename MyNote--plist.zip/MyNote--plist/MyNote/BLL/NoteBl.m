//
//  NoteBl.m
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "NoteBl.h"
#import "NoteDAO.h"

@implementation NoteBl

+(NSMutableArray *)createNote:(Note *)model{
    NoteDAO * dao = [NoteDAO sharedManager];
    [dao creat:model];
    return [dao findAll];
}

+(NSMutableArray *)remove:(Note *)model{
    NoteDAO * dao = [NoteDAO sharedManager];
    [dao remove:model];
    return [dao findAll];
}
+(NSMutableArray *)findAll{
    NoteDAO * dao = [NoteDAO sharedManager];
    return [dao findAll];
}

+(NSMutableArray *)chageNote:(Note *)model{
    NoteDAO * dao = [NoteDAO sharedManager];
    [dao modify:model];
    return [dao findAll];
}

@end
