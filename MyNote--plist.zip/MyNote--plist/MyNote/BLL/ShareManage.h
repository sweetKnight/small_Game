//
//  ShareManage.h
//  ZhongGuoCha
//
//  Created by 张长乐 on 15/5/20.
//  Copyright (c) 2015年 BMCL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShareSDK/ShareSDK.h>
#import <ShareSDKConnector/ShareSDKConnector.h>
@interface ShareManage : NSObject

+ (void)shareHandlerByShareType:(ShareType)shareType prameDic:(NSDictionary*)dic backBlock:(void(^)(BOOL isSUC))backBlcok;
@end
