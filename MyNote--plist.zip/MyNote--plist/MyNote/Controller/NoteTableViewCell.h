//
//  NoteTableViewCell.h
//  MyNote
//
//  Created by 冯剑锋 on 16/3/5.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "SmartTableViewCell.h"
#import "Note.h"

typedef void(^DelectButtonClick)(NSIndexPath * index);

@interface NoteTableViewCell : SmartTableViewCell
@property (nonatomic, copy) DelectButtonClick block;
@property (nonatomic, strong) NSIndexPath * index;
@property (nonatomic, strong) Note * model;
@end
