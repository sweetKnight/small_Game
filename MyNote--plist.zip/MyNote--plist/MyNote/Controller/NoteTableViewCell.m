//
//  NoteTableViewCell.m
//  MyNote
//
//  Created by 冯剑锋 on 16/3/5.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "NoteTableViewCell.h"

@interface NoteTableViewCell (){
    CGFloat offeseWitdh;
}
@property (nonatomic, strong) UIView * bgView;
@property (nonatomic, strong) UIImageView * headImageView;
@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) UILabel * messageLabel;
@property (nonatomic, strong) UILabel * timeLabel;
@property (nonatomic, strong) UIButton * deleteButton;
@end

@implementation NoteTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _bgView = [[UIView alloc]init];
        [self.contentView addSubview:_bgView];
        
        _headImageView = [[UIImageView alloc]init];
        _headImageView.image = [UIImage imageNamed:@"note_image_baseBg"];
        [_bgView addSubview:_headImageView];
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = DEF_FontSize_15;
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.textColor = getColor(grayColor);
        [_bgView addSubview:_titleLabel];
        
        _messageLabel = [[UILabel alloc]init];
        _messageLabel.font = DEF_FontSize_14;
        _messageLabel.textAlignment = NSTextAlignmentLeft;
        _messageLabel.textColor = getColor(grayColor);
        [_bgView addSubview:_messageLabel];
        
        _timeLabel = [[UILabel alloc]init];
        _timeLabel.font = DEF_FontSize_10;
        _timeLabel.textAlignment = NSTextAlignmentRight;
        _timeLabel.textColor = getColor(grayColor);
        [_bgView addSubview:_timeLabel];
        
        _deleteButton = [[UIButton alloc]init];
        [_deleteButton setBackgroundImage:[UIImage imageNamed:@"cell_delete"] forState:UIControlStateNormal];
        [_deleteButton addTarget:self action:@selector(deleteButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [_bgView addSubview:_deleteButton];
        
        UISwipeGestureRecognizer *leftSwipeGesture=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(leftSwipe:)];
        leftSwipeGesture.direction=UISwipeGestureRecognizerDirectionLeft;
        [self.bgView addGestureRecognizer:leftSwipeGesture];
        
        UISwipeGestureRecognizer *rightSwipeGesture=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe:)];
        rightSwipeGesture.direction=UISwipeGestureRecognizerDirectionRight;
        [self.bgView addGestureRecognizer:rightSwipeGesture];
        
//        [self test];
    }
    return self;
}

-(void)layoutSubviews{
    _bgView.frame = CGRectMake(0, 0, self.bounds.size.width + 35, self.bounds.size.height);
    
    _headImageView.frame = CGRectMake(10, 10, self.bounds.size.height - 20, self.bounds.size.height - 20);
    _headImageView.layer.cornerRadius = DEF_HEIGHT(_headImageView)/4;
    _headImageView.layer.masksToBounds = YES;
    _messageLabel.frame = CGRectMake(DEF_RIGHT(_headImageView)+10, DEF_HEIGHT(_headImageView)/2+10, self.bounds.size.width - DEF_RIGHT(_headImageView)-20, DEF_HEIGHT(_headImageView)/2);
    CGRect tempRect = CGRectOffset(_messageLabel.frame, 0, -DEF_HEIGHT(_messageLabel));
    
    _titleLabel.frame = CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width/3*2, tempRect.size.height);
    _timeLabel.frame = CGRectMake(DEF_RIGHT(_titleLabel), DEF_TOP(_titleLabel), DEF_WIDTH(_messageLabel) - DEF_WIDTH(_titleLabel), DEF_HEIGHT(_titleLabel));
    
    _deleteButton.frame = CGRectMake(self.bounds.size.width, 0, 35, self.bounds.size.height);
    offeseWitdh = 35;
}

-(void)leftSwipe:(UISwipeGestureRecognizer *)gesture{
    if (_bgView.frame.origin.x == 0) {
        [UIView animateWithDuration:0.25 animations:^{
            _bgView.frame = CGRectOffset(_bgView.frame, -offeseWitdh+2, 0);
        }];
    }
}

-(void)rightSwipe:(UISwipeGestureRecognizer *)gesture{
    if ((int)_bgView.frame.origin.x == (int)(-offeseWitdh+2)) {
        [UIView animateWithDuration:0.25 animations:^{
            _bgView.frame = CGRectOffset(_bgView.frame, offeseWitdh-2, 0);
        }];
    }
}

-(void)deleteButtonClick{
    if (_block) {
        _block(_index);
    }
}

-(void)setModel:(Note *)model{
    if (![[[NSString alloc]initWithData:model.image encoding:NSUTF8StringEncoding] isEqualToString:@"noImage"]) {
        _headImageView.image = [UIImage imageWithData:model.image];
    }
    _titleLabel.text = model.title;
    _timeLabel.text = [[NSString stringWithFormat:@"%@",model.date] substringToIndex:10];
    _messageLabel.text = model.content;
}

-(void)test{
    _headImageView.backgroundColor = [UIColor greenColor];
    _titleLabel.text = @"欢迎使用My Note";
    _timeLabel.text = @"2016-03-05";
    _messageLabel.text = @"额就是挺好的你就用着吧~~";
}

@end
