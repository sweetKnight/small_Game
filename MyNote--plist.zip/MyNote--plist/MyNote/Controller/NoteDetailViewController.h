//
//  NoteDetailViewController.h
//  MyNote
//
//  Created by 冯剑锋 on 16/3/5.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "BaseViewController.h"
#import "Note.h"

@interface NoteDetailViewController : BaseViewController
@property (nonatomic, strong) Note * baseNote;
@property (nonatomic, assign) BOOL isCreate;
@end
