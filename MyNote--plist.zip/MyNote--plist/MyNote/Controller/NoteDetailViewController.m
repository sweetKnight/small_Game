//
//  NoteDetailViewController.m
//  MyNote
//
//  Created by 冯剑锋 on 16/3/5.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "NoteDetailViewController.h"
#import "NoteBl.h"

#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>


@interface NoteDetailViewController ()
<UITextViewDelegate,
 UIImagePickerControllerDelegate,
 UIActionSheetDelegate,
 UINavigationControllerDelegate>
{
    UIImage *_image;
}

@property (nonatomic, strong) UIButton * headButton;
@property (nonatomic, strong) UITextView * noteMessageTextView;
@property (nonatomic, strong) UILabel * textViewLabel;
@property (nonatomic, strong) UITextField * tiltelTextView;
@end

@implementation NoteDetailViewController

#pragma mark - init

#pragma mark - lifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Note Message";
    [self uiMake];
    if (!_isCreate) {
        if (![[[NSString alloc]initWithData:_baseNote.image encoding:NSUTF8StringEncoding] isEqualToString:@"noImage"]) {
            [_headButton setBackgroundImage:[UIImage imageWithData:_baseNote.image] forState:UIControlStateNormal];
        }
        _image = [UIImage imageWithData:_baseNote.image];
        _tiltelTextView.text = _baseNote.title;
        _noteMessageTextView.text = _baseNote.content;
        _textViewLabel.hidden = YES;
    }
}

-(void)uiMake{
    
    UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 10, DEF_SCREEN_WIDTH, 45)];
    bgView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:bgView];
    
    _headButton = [[UIButton alloc]initWithFrame:CGRectMake(10, 0, 45, 45)];
    [_headButton setBackgroundImage:[UIImage imageNamed:@"add_headImage"] forState:UIControlStateNormal];
    _headButton.layer.cornerRadius = DEF_HEIGHT(_headButton)/4;
    _headButton.layer.masksToBounds = YES;
    [_headButton addTarget:self action:@selector(selectImageForNote) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:_headButton];
    
    
    
    _tiltelTextView = [[UITextField alloc]initWithFrame:CGRectMake(65, 10, DEF_SCREEN_WIDTH-75, 45)];
    _tiltelTextView.font = DEF_FontSize_16;
    _tiltelTextView.placeholder = @"标题";
    [self.view addSubview:_tiltelTextView];
    
    _noteMessageTextView = [[UITextView alloc]initWithFrame:CGRectMake(0, DEF_BOTTOM(_tiltelTextView) + 10, DEF_SCREEN_WIDTH, 100)];
    _noteMessageTextView.delegate = self;
    _noteMessageTextView.font = DEF_FontSize_16;
    [self.view addSubview:_noteMessageTextView];
    
    _textViewLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, DEF_SCREEN_WIDTH - 30, 20)];
    _textViewLabel.font = DEF_FontSize_16;
    _textViewLabel.textColor = getColor(@"A9A9A9");
    _textViewLabel.text = @"内容";
    [_noteMessageTextView addSubview:_textViewLabel];
}

#pragma mark - UITextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView{
    _textViewLabel.hidden = YES;
    
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if (textView.text.length == 0) {
        _textViewLabel.hidden = NO;
    }
}

#pragma mark - buttonClick

- (IBAction)saveNote:(id)sender {
    Note * note = [[Note alloc]init];
    note.title = _tiltelTextView.text;
    note.content = _noteMessageTextView.text;
    if (_image != nil) {
        note.image = UIImageJPEGRepresentation(_image, 0.0001);
    }else{
        note.image = [@"noImage" dataUsingEncoding:NSUTF8StringEncoding];
    }
    if (_isCreate) {
        note.date = [NSDate date];
        [NoteBl createNote:note];
    }else{
        note.date = _baseNote.date;
        [NoteBl chageNote:note];
    }
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)selectImageForNote{
    [self showOkayCancelAlert];
}

#pragma mark - 选择相册方法---只支持选择一张照片

/**
 *  调出actionshoot（唯一在代码里要用的方法）
 */
- (void)showOkayCancelAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    // Create the actions.
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
    }];
    
    UIImagePickerController * imagePickerController= [[UIImagePickerController alloc]init];
    imagePickerController.delegate = self;
    UIAlertAction *takingAction = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![self confirmCamera]) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"摄像头不可用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
            return;
        }
        imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;//相册
        imagePickerController.allowsEditing=YES;
        [self presentViewController:imagePickerController animated:YES completion:^{}];
    }];
    
    UIAlertAction *photoAction = [UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//相册
        imagePickerController.allowsEditing=YES;
        [weakSelf presentViewController:imagePickerController animated:YES completion:^{}];
    }];
    
    // Add the actions.
    [alertController addAction:cancelAction];
    [alertController addAction:takingAction];
    [alertController addAction:photoAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

/**
 *  判断是否支持相机
 */
- (BOOL)confirmCamera
{
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
        
        NSLog(@"相机权限受限");
        return NO;
    }
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]&&[UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear];
}

#pragma mark - UIImagePickerControllerDelegate
/**
 *  选择照片后返回的方法
 */
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *img=info[UIImagePickerControllerEditedImage];
    [picker dismissViewControllerAnimated:YES completion:nil];
    _image= img;
    [_headButton setBackgroundImage:img forState:UIControlStateNormal];
}

@end
