//
//  BaseViewController.m
//  TangRen
//
//  Created by CNBJCHENRJM021 on 16/2/2.
//  Copyright © 2016年 KeJiang. All rights reserved.
//

#import "BaseViewController.h"


@interface BaseViewController ()
{
    UIButton *backBtn;
    
    UIButton *rightBtn;
}
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = getColor(@"F7F7F7");
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self setupForDismissKeyboard];
    
    UIBarButtonItem * button =[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:nil action:nil];
    self.navigationItem.backBarButtonItem = button;
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTranslucent:YES];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:25.0f],NSForegroundColorAttributeName: [UIColor whiteColor]}];
   }

- (void)createleftBtnWithStr:(NSString *)str{
    backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 18, 18);
    [backBtn setImage:[UIImage imageNamed:str] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backTo) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
}

- (void)backTo{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)hiddenLeftBtn{
    backBtn.hidden = YES;
}


- (void)createRightBtnWithStr:(NSString *)str{
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:str] style:UIBarButtonItemStylePlain target:self action:@selector(rightAction)];
    [rightItem setTintColor:getColor(grayColor)];
    self.navigationItem.rightBarButtonItem = rightItem;
}
- (void)rightAction{
    
}

- (void)hiddenRightBtn:(BOOL)state{
    rightBtn.hidden = state;
}


- (void) showMessage:(NSString*)message{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    [alert show];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [alert dismissWithClickedButtonIndex:alert.cancelButtonIndex animated:YES];
    });
}

@end
