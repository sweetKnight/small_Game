//
//  BaseViewController.h
//  TangRen
//
//  Created by CNBJCHENRJM021 on 16/2/2.
//  Copyright © 2016年 KeJiang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+DismissKeyboard.h"

@interface BaseViewController : UIViewController

- (void)createleftBtnWithStr:(NSString *)str;
- (void)createRightBtnWithStr:(NSString *)str;
- (void)rightAction;
- (void)backTo;
- (void)hiddenLeftBtn;
- (void)hiddenRightBtn:(BOOL)state;
- (void) showMessage:(NSString*)message;

@end
