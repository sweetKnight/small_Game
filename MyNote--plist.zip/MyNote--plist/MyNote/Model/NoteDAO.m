//
//  NoteDAO.m
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "NoteDAO.h"
#import <UIKit/UIKit.h>

@implementation NoteDAO
static NoteDAO *sharedManager = nil;

+(NoteDAO *)sharedManager{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedManager = [[self alloc]init];
        sharedManager.listData = [[NSMutableArray alloc]init];
        [sharedManager createEditTableCopyOfDatabaseIfNeeded];
    });
    return sharedManager;
}

-(int)creat:(Note *)model{
    NSString * path = [self applicationDDocumentsDirectoryFile];
    NSMutableArray * array = [[NSMutableArray alloc]initWithContentsOfFile:path];
    NSDictionary * noteDic =[model chageToDictionary];
    [array addObject:noteDic];
    [array writeToFile:path atomically:YES];
    return 0;
}

-(int)remove:(Note *)model{
    NSString * path = [self applicationDDocumentsDirectoryFile];
    NSMutableArray * array = [[NSMutableArray alloc]initWithContentsOfFile:path];
    for (NSDictionary *dict in array) {
        if ([dict[@"noteData"] isEqualToDate:model.date]) {
            [array removeObject:dict];
            [array writeToFile:path atomically:YES];
            return 0;
        }
    }
    return 1;
}

-(int)modify:(Note *)model{
    NSString * path = [self applicationDDocumentsDirectoryFile];
    NSMutableArray * array = [[NSMutableArray alloc]initWithContentsOfFile:path];
    for (NSDictionary *dict in array) {
        if ([dict[@"noteData"] isEqualToDate:model.date]) {
            [dict setValue:model.title forKey:@"noteTitle"];
            [dict setValue:model.content forKey:@"noteContent"];
            [dict setValue:model.image forKey:@"noteImage"];
            [array writeToFile:path atomically:YES];
            return 0;
        }
    }
    return 1;
}

-(NSMutableArray *)findAll{
    NSString * path = [self applicationDDocumentsDirectoryFile];
    NSMutableArray * array = [[NSMutableArray alloc]initWithContentsOfFile:path];
    NSMutableArray * listArray = [[NSMutableArray alloc]initWithCapacity:array.count];
    [array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        Note *note = [[Note alloc]initWithDic:obj];
        [listArray addObject:note];
    }];
    return listArray;
}

-(Note *)findById:(Note *)model{
    NSString * path = [self applicationDDocumentsDirectoryFile];
    NSMutableArray * array = [[NSMutableArray alloc]initWithContentsOfFile:path];
    for (NSDictionary *dict in array) {
        if ([dict[@"noteData"] isEqualToDate:model.date]) {
            Note * note = [[Note alloc]initWithDic:dict];
            return note;
        }
    }
    return nil;
}

#pragma mark - userDefaultOperation
-(void)saveNotesToUserDefault{
    NSMutableArray * tempArray = [[NSMutableArray alloc]init];
    [sharedManager.listData enumerateObjectsUsingBlock:^(Note * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary * dic = [obj chageToDictionary];
        [tempArray addObject:dic];
    }];
    [[NSUserDefaults standardUserDefaults] setObject:tempArray forKey:MyNotesListArray];
}

-(void)extractDataFormUserDefault{
    NSMutableArray * tempArray = [[[NSUserDefaults standardUserDefaults] arrayForKey:MyNotesListArray] mutableCopy];
    [sharedManager.listData removeAllObjects];
    [tempArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        Note *note = [[Note alloc]initWithDic:obj];
        [sharedManager.listData addObject:note];
    }];
}

#pragma mark - plistOperation

-(void)createEditTableCopyOfDatabaseIfNeeded{
    NSFileManager * fileManage = [NSFileManager defaultManager];
    NSString * writableDBPath = [self applicationDDocumentsDirectoryFile];
    
    BOOL dbexits = [fileManage fileExistsAtPath:writableDBPath];
    if (!dbexits) {
        NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"NotesList.plist"];
        NSError *error;
        BOOL success = [fileManage copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
        NSAssert(success, @"错误写入文件");
    }
}

-(NSString *)applicationDDocumentsDirectoryFile{
    NSString *documentDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString * path = [documentDirectory stringByAppendingPathComponent:@"NotesList.plist"];
    
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        DEBUGLog(@"%@",path);
    });
    return path;
}


@end
