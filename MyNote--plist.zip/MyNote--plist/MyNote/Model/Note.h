//
//  Note.h
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Note : NSObject
@property (nonatomic, copy) NSString * content;
@property (nonatomic, copy) NSString * title;
@property (nonatomic, strong) NSDate * date;
@property (nonatomic, strong) NSData * image;

/*!
 *  用字典创建本类
 *
 *  @param dic 字典
 *
 *  @return 返回note类
 */
-(instancetype)initWithDic:(NSDictionary *)dic;
/*!
 *  将本类实体转化为字典
 *
 *  @return 字典
 */
-(NSDictionary *)chageToDictionary;
@end
