//
//  NoteDAO.h
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Note.h"

@interface NoteDAO : NSObject
/*!
 *  保存数据列表
 */
@property (nonatomic, strong) NSMutableArray<Note *> *listData;

+(NoteDAO *)sharedManager;
/*!
 *  插入备忘录方法
 */
-(int)creat:(Note *)model;
/*!
 *  删除备忘录方法
 */
-(int)remove:(Note *)model;
/*!
 *  修改备忘录方法
 */
-(int)modify:(Note *)model;
/*!
 *  查询所有数据方法
 */
-(NSMutableArray *)findAll;
/*!
 *  按照主键查询数据的方法
 */
-(Note *)findById:(Note *)model;
@end
