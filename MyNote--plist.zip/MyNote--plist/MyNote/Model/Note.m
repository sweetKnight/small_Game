//
//  Note.m
//  MyNote
//
//  Created by 冯剑锋 on 16/3/6.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "Note.h"

@implementation Note
-(instancetype)initWithDic:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        _title = dic[@"noteTitle"];
        _content = dic[@"noteContent"];
        _date = dic[@"noteData"];
        _image = dic[@"noteImage"];
    }
    return self;
}

-(NSDictionary *)chageToDictionary{
    NSDictionary * dic = @{@"noteTitle":_title
                           ,@"noteContent":_content
                           ,@"noteData":_date,
                           @"noteImage":_image};
    return dic;
}

@end
