//
//  AppDelegate.h
//  TanChiShe
//
//  Created by fwzx26 on 15/5/8.
//  Copyright (c) 2015年 sweet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

