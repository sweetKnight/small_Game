//
//  ViewController.m
//  TanChiShe
//
//  Created by fwzx26 on 15/5/8.
//  Copyright (c) 2015年 sweet. All rights reserved.
//

#import "ViewController.h"
#import "UIView+Ext.h"

//枚举定义方向变量
typedef enum {
    up,
    down,
    left,
    right
} changeDirection;

//定义代表方向的的参数，和存放蛇身体节点的数组
@interface ViewController ()
{
    changeDirection  _fangxiang;
    NSMutableArray * _snake;
    UIView *  _sugra;
    UIView * gameground;
}


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _snake= [[NSMutableArray alloc]init];
    
    //创建一个游戏的面板
    gameground = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 400, 300)];
    gameground.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:gameground];
    
    //创建初始的蛇节点,并存放在_snake数组
    for (int i = 0; i < 4; i++) {
        UIView * snakePoin = [[UIView alloc]initWithFrame:
                              CGRectMake(i * 10, 0, 10, 10)];
        snakePoin.backgroundColor = [UIColor redColor];
        [_snake addObject:snakePoin];
        [gameground addSubview:snakePoin];
       
    }
    
    //创建初始糖果
     _sugra = [[UIView alloc]initWithFrame:CGRectMake(((arc4random()%40) *10),((arc4random()%30) * 10), 10, 10)];
    _sugra.backgroundColor = [UIColor greenColor];
    [gameground addSubview:_sugra];
    
    
    //计时器使蛇移动方法循环调用
    _fangxiang = down;
    
    [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(moveSnake:) userInfo:nil repeats:YES];
    
    
    
}

//让蛇移动
-(void)moveSnake: (NSTimer *) timer{
   
    UIView * view = [_snake firstObject];
    switch (_fangxiang) {
        case right:{
            for (int i = (int)_snake.count - 1 ; i > 0; i--) {
                UIView * view1 = [_snake objectAtIndex: i];
                UIView * view2 = [_snake objectAtIndex: i - 1];
                view1.frame = view2.frame;
            }
            view. right+= 10;
            
            
            break;
        }
        case left:{
            for (int i = (int)_snake.count - 1 ; i > 0; i--) {
                UIView * view1 = [_snake objectAtIndex: i];
                UIView * view2 = [_snake objectAtIndex: i - 1];
                view1.frame = view2.frame;
            }
            view. left-= 10;
            break;
        }
        case up:{
            for (int i = (int)_snake.count - 1 ; i > 0; i--) {
                UIView * view1 = [_snake objectAtIndex: i];
                UIView * view2 = [_snake objectAtIndex: i - 1];
                view1.frame = view2.frame;
            }
            view. top-= 10;
            break;
        }
        case down:{
            for (int i = (int)_snake.count - 1 ; i > 0; i--) {
                UIView * view1 = [_snake objectAtIndex: i];
                UIView * view2 = [_snake objectAtIndex: i - 1];
                view1.frame = view2.frame;
            }
            view. bottom+= 10;
            break;
        }
        default:
            break;
    }
    
    //如果迟到糖果将糖果加到蛇数组里
    if ([[NSValue valueWithCGRect:view.frame] isEqualToValue: [NSValue valueWithCGRect:_sugra.frame]]) {
        UIView * addView = [[UIView alloc]init];
        addView.frame = _sugra.frame;
        addView.backgroundColor = [UIColor redColor];
        [gameground addSubview:addView];
        [_snake addObject:addView];
        
        [_sugra removeFromSuperview];
        //创建初始糖果
        _sugra = [[UIView alloc]initWithFrame:CGRectMake(((arc4random()%40) *10),((arc4random()%30) * 10), 10, 10)];
        _sugra.backgroundColor = [UIColor greenColor];
        [gameground addSubview:_sugra];
        
        for(int i = 1 ; i < (int)_snake.count - 1; i++) {
            UIView * tmpView = [_snake objectAtIndex:i];
            if ([[NSValue valueWithCGRect:_sugra.frame] isEqualToValue:[NSValue valueWithCGRect:tmpView.frame]]) {
                [_sugra removeFromSuperview];
                //创建初始糖果
                _sugra = [[UIView alloc]initWithFrame:CGRectMake(((arc4random()%40) *10),((arc4random()%30) * 10), 10, 10)];
                _sugra.backgroundColor = [UIColor greenColor];
                [gameground addSubview:_sugra];
                
            }

        }

    }
    
    for(int i = 1 ; i < (int)_snake.count - 1; i++) {
        UIView * tmpView = [_snake objectAtIndex:i];
        if ([[NSValue valueWithCGRect:view.frame] isEqualToValue:[NSValue valueWithCGRect:tmpView.frame]] ) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"标题" message:@"你死了" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            [alertView show];
            [timer invalidate];
        }
    }
    
    //走到头返回
    if (view.top == -10) {
        view.bottom = 300;
    }
    if (view.bottom == 310) {
        view.top = 0;
    }
    if (view.left == -10) {
        view.right = 400;
    }
    if (view.right == 410) {
        view.left = 0;
    }
    
}


- (IBAction)upButton:(id)sender {
    if (_fangxiang != down) {
        _fangxiang = up;
    }
    
}

- (IBAction)downButton:(id)sender {
    if (_fangxiang != up) {
        _fangxiang = down;
    }
    
}

- (IBAction)leftButton:(id)sender {
    if (_fangxiang != right) {
        _fangxiang = left;
    }
    
}

- (IBAction)rightButton:(id)sender {
    if (_fangxiang != left) {
        _fangxiang = right;
    }
    
}

@end
