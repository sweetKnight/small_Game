//
//  ViewController.h
//  TanChiShe
//
//  Created by fwzx26 on 15/5/8.
//  Copyright (c) 2015年 sweet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)upButton:(id)sender;

- (IBAction)downButton:(id)sender;
- (IBAction)leftButton:(id)sender;
- (IBAction)rightButton:(id)sender;

-(void)moveSnake: (NSTimer *) timer;


@end

