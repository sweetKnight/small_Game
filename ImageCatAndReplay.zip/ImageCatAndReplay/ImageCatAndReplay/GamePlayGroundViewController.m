//
//  GamePlayGroundViewController.m
//  ImageCatAndReplay
//
//  Created by 冯剑锋 on 16/2/24.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "GamePlayGroundViewController.h"
#import "SweetConfig.h"
#import "ImageCollectionViewCell.h"
#import "CellModel.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>

@interface GamePlayGroundViewController ()
<UICollectionViewDataSource,
UICollectionViewDelegate,
UIImagePickerControllerDelegate,
UIActionSheetDelegate,
UINavigationControllerDelegate>
{
    BOOL isShouldExChange;
    NSIndexPath * exChangeIndex;
    int stepNum;
    int promptNum;
}
@property (weak, nonatomic) IBOutlet UILabel *promptNumber;
@property (weak, nonatomic) IBOutlet UILabel *stepNumber;

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray<CellModel *> * dataArray;
@property (nonatomic, strong) UIImage * bgImage;
@property (nonatomic, strong) UIView * popView;
@property (nonatomic, strong) UIImageView * promptImageView;
@end

@implementation GamePlayGroundViewController

#pragma mark - init

-(void)setPromptNumber:(UILabel *)promptNumber{
    _promptNumber = promptNumber;
    promptNum = 3;
    _promptNumber.text = [NSString stringWithFormat:@"可用提示数:%i", promptNum];
}

-(void)setStepNumber:(UILabel *)stepNumber{
    _stepNumber = stepNumber;
    stepNum = 0;
    _stepNumber.text = [NSString stringWithFormat:@"已用步骤:%i", stepNum];
}

-(void)setCollectionView:(UICollectionView *)collectionView{
    _collectionView = collectionView;
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.minimumInteritemSpacing = 0;
    layout.minimumLineSpacing = 0;
    CGFloat itemWidth = (DEF_SCREEN_WIDTH - 40)/3;
//    CGFloat itemHeight = DEF_HEIGHT(_collectionView)/3;
    layout.itemSize = CGSizeMake(itemWidth, itemWidth);
    _collectionView.collectionViewLayout = layout;
    _collectionView.bounces = NO;
    _collectionView.backgroundColor = [UIColor clearColor];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.layer.cornerRadius = 5;
    _collectionView.layer.masksToBounds = YES;
//    _collectionView.layer.borderWidth = 1;
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.showsHorizontalScrollIndicator = NO;
    [_collectionView registerClass:[ImageCollectionViewCell class] forCellWithReuseIdentifier:NSStringFromClass([ImageCollectionViewCell class])];
}

-(NSMutableArray *)dataArray{
    if (nil == _dataArray) {
        _dataArray = [[NSMutableArray alloc]initWithCapacity:9];
        for (int i = 0; i < 9; i++) {
            CellModel * model = [[CellModel alloc]init];
            [_dataArray addObject:model];
        }
    }
    return _dataArray;
}

-(UIView *)popView{
    if (nil == _popView) {
        _popView = [[UIView alloc]initWithFrame:CGRectMake(-DEF_SCREEN_WIDTH, 0, DEF_SCREEN_WIDTH, DEF_SCREEN_HEIGHT)];
        _popView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
        _promptImageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, 20, _popView.frame.size.width - 40, (_popView.frame.size.width - 40)*(_bgImage.size.width/_bgImage.size.height))];
        _promptImageView.image = _bgImage;
        [_popView addSubview:_promptImageView];
    }
    return _popView;
}

#pragma mark - lifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = getColor(@"f2f2f2");
    _bgImage = [UIImage imageNamed:@"gameBaseImage.jpeg"];
    [self resetDataArray];
    
    [self.view addSubview:self.popView];
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ImageCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ImageCollectionViewCell class]) forIndexPath:indexPath];
    cell.imageView.image = [[self.dataArray objectAtIndex:indexPath.row] image];
    cell.row = [[self.dataArray objectAtIndex:indexPath.row] row];
    return cell;
}

#pragma mark - collectionViewdelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (isShouldExChange) {
        if (abs(exChangeIndex.row - indexPath.row) == 1 || abs(exChangeIndex.row - indexPath.row) == 3) {
            
            //利用判断使它不能折行交换
            if (exChangeIndex.row == 2&&indexPath.row == 3) {
                return;
            }
            if (exChangeIndex.row == 3&&indexPath.row == 2) {
                return;
            }
            if (exChangeIndex.row == 5&&indexPath.row == 6) {
                return;
            }
            if (exChangeIndex.row == 6&&indexPath.row == 5) {
                return;
            }
            
            [self.dataArray exchangeObjectAtIndex:indexPath.row withObjectAtIndex:exChangeIndex.row];
            [self.collectionView reloadData];
            isShouldExChange = NO;
            stepNum ++;
            _stepNumber.text = [NSString stringWithFormat:@"已用步骤:%i", stepNum];
            if ([self isSuccessful]) {
                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"恭喜使用了%i你成功完成拼图", stepNum] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alert show];
            }
        }
    }else{
        exChangeIndex = indexPath;
        isShouldExChange = YES;
    }
}

#pragma mark - buttonClick
- (IBAction)difficultyClick:(id)sender {
    if (promptNum == 0) {
        return;
    }
    [UIView animateWithDuration:1 animations:^{
        self.popView.frame = self.view.bounds;
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:1 animations:^{
            self.popView.frame = CGRectMake(-DEF_SCREEN_WIDTH, 0, DEF_SCREEN_WIDTH, DEF_SCREEN_HEIGHT);
        }];
    });
    promptNum --;
    _promptNumber.text = [NSString stringWithFormat:@"可用提示数:%i", promptNum];
}
- (IBAction)resetClick:(id)sender {
    [self resetDataArray];
}
- (IBAction)uploadClick:(id)sender {
    [self showOkayCancelAlert];
}

#pragma mark - customeMethods

-(void)resetDataArray{
    CGFloat imageItemWithd = _bgImage.size.width/3;
    CGFloat imageItemHeight = _bgImage.size.height/3;
    
    for (int i = 0; i < self.dataArray.count; i++) {
        if (i<3) {
            self.dataArray[i].image = [self cutImage:_bgImage AndRect:CGRectMake(imageItemWithd*i, 0, imageItemWithd, imageItemHeight)];
            self.dataArray[i].row = i;
            
        }else if(i < 6){
            self.dataArray[i].image = [self cutImage:_bgImage AndRect:CGRectMake(imageItemWithd*(i-3), imageItemHeight, imageItemWithd, imageItemHeight)];
            self.dataArray[i].row = i;
        }else{
            self.dataArray[i].image = [self cutImage:_bgImage AndRect:CGRectMake(imageItemWithd*(i-6), imageItemHeight*2, imageItemWithd, imageItemHeight)];
            self.dataArray[i].row = i;
        }
    }
    
    for (int j = 0; j < 6; j++) {
        [self.dataArray exchangeObjectAtIndex:0 withObjectAtIndex:arc4random()%8];
    }
    
    [_collectionView reloadData];
}

-(UIImage *)cutImage:(UIImage *)image AndRect:(CGRect)rect{
    CGImageRef imageRef = image.CGImage;
    CGImageRef imagePartRef = CGImageCreateWithImageInRect(imageRef, rect);
    UIImage *cropImage = [UIImage imageWithCGImage:imagePartRef];
    CGImageRelease(imagePartRef);
    return cropImage;
}

-(BOOL)isSuccessful{
    __block BOOL isSuccessful = YES;
    
    [self.dataArray enumerateObjectsUsingBlock:^(CellModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (obj.row != idx) {
            isSuccessful = NO;
            *stop = YES;
        }
    }];
    return isSuccessful;
}

#pragma mark - 选择相片
- (BOOL)confirmCamera
{
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
        
        NSLog(@"相机权限受限");
        return NO;
    }
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]&&[UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear];
}

- (void)showOkayCancelAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    // Create the actions.
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
    }];
    
    UIImagePickerController * imagePickerController= [[UIImagePickerController alloc]init];
    imagePickerController.delegate = self;
    UIAlertAction *takingAction = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![self confirmCamera]) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"摄像头不可用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
            return;
        }
        imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;//相册
        imagePickerController.allowsEditing=YES;
        [self presentViewController:imagePickerController animated:YES completion:^{}];
    }];
    
    UIAlertAction *photoAction = [UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//相册
        imagePickerController.allowsEditing=YES;
        [weakSelf presentViewController:imagePickerController animated:YES completion:^{}];
    }];
    
    // Add the actions.
    [alertController addAction:cancelAction];
    [alertController addAction:takingAction];
    [alertController addAction:photoAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}


#pragma mark -
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *img=info[UIImagePickerControllerEditedImage];
    [picker dismissViewControllerAnimated:YES completion:nil];
    //    _imageString = img;
    _bgImage = img;
    [self resetDataArray];
    _promptImageView.image = _bgImage;
}


@end
