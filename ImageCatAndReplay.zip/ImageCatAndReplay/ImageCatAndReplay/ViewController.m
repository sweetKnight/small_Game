//
//  ViewController.m
//  ImageCatAndReplay
//
//  Created by 冯剑锋 on 16/2/24.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    imageView.center = self.view.center;
    imageView.image = [self cutImage:[UIImage imageNamed:@"gameBaseImage.jpeg"] AndRect:CGRectMake(200, 50, 350, 350)];
//    imageView.image = [UIImage imageNamed:@"gameBaseImage.jpeg"];
    [self.view addSubview:imageView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIImage *)cutImage:(UIImage *)image AndRect:(CGRect)rect{
    CGImageRef imageRef = image.CGImage;
    CGImageRef imagePartRef = CGImageCreateWithImageInRect(imageRef, rect);
    UIImage *cropImage = [UIImage imageWithCGImage:imagePartRef];
    CGImageRelease(imagePartRef);
    return cropImage;
}

@end
