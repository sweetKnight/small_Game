//
//  ImageCollectionViewCell.m
//  ImageCatAndReplay
//
//  Created by 冯剑锋 on 16/2/24.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

#import "ImageCollectionViewCell.h"

@interface ImageCollectionViewCell ()

@end

@implementation ImageCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.borderColor = [UIColor blackColor].CGColor;
        self.layer.borderWidth = 1;
        
        _imageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_imageView];
    }
    return self;
}

-(void)layoutSubviews{
    _imageView.frame = self.bounds;
}

@end
